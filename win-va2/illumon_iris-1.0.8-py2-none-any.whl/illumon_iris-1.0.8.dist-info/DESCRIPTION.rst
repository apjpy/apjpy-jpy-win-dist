Illumon Python Package
======================

This project is for the illumon-iris python package on PyPI.

----

Iris is a time-series database product from Illumon.
This package provides provide Python integrations for Iris.

Usage
-----

    >>> import illumon-iris
    >>> ...


