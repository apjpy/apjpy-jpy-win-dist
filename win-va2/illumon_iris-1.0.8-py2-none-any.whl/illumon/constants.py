#
# Copyright (c) 2016-2017 Illumon and Patent Pending
#

NULL_CHAR = 65534
NULL_FLOAT = float.fromhex('-0x1.fffffep127')
NULL_DOUBLE = float.fromhex('-0x1.fffffffffffffP+1023')
NULL_SHORT = -32768
NULL_INT = -0x80000000
NULL_LONG = -0x8000000000000000
NULL_BYTE = -128
